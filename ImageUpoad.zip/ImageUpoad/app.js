const express = require('express');
const path = require('path');
const crypto = require('crypto');
const bodyParser = require('body-parser');
const multer = require('multer');
const Grid = require('gridfs-stream');
const GridFsStorage = require('multer-gridfs-storage');
const methodOverride = require('method-override');
const mongoose = require('mongoose');

const app = express();

app.use(bodyParser.json());

//tells the program we want to use a query string when creating our
//form as to make a delete request
app.use(methodOverride('_method'));

//MongoDB URI
const mongoURI = 'mongodb://csciTeam:csci4300@ds153869.mlab.com:53869/cookbook';
//create DB connection
const conn = mongoose.createConnection(mongoURI);
let gfs;
conn.once('open', () => {
   gfs = Grid(conn.db, mongoose.mongo);
   gfs.collection('upload');
});
//Create storage object
const storage = new GridFsStorage({
    url: mongoURI,
    file: (req, file) => {
        return new Promise((resolve, reject) => {
            crypto.randomBytes(16, (err, buf) => {
                if (err) {return reject(err);}
                //if no err use crypto to create the hexCode file name + the original
                //this prevents having files of the same name
                //const category = file.originalname;
                //const fileName = buf.toString('hex') + path.extname(file.originalname);
                const fileName = file.originalname;
                const fileInfo = {
                   //category: category,
                   filename: fileName,
                   bucketName: 'upload'
                };
                resolve(fileInfo);
            });
        });
    }
});
const upload = multer({storage});

//
app.post('/upload', upload.single('file'),(req, res) => {
    //testing if the file was stored
    //res.json({file: req.file});

    //go back to homepage
    res.redirect('/');
});

//@rout GET /files
//@desc display all files JSON
app.get('/files', (req, res) => {
    gfs.files.find().toArray((err, files) => { 
        if (!files || files.length === 0) {
            return res.status(404).json({
                err: 'No files exist'
            });
        }
        return res.json(files);
    });
});

//@rout GET /files/:file
//@desc display singe files JSON
app.get('/files/:fileName', (req, res) => {
    gfs.files.findOne({filename: req.params.fileName}, (err,file) => { 
        if (!file || file.length === 0) {
            return res.status(404).json({
                err: 'No files exist'
            });
        }
        return res.json(file);
    });
});

//@rout GET /image/:fileName
//@desc display singe image
app.get('/image/:fileName', (req, res) => {
    gfs.files.findOne({filename: req.params.fileName}, (err,file) => { 
        if (!file || file.length === 0) {
            return res.status(404).json({
                err: 'No files exist'
            });
        }
        //check if file is jpg or png
        if (file.contentType === 'image/jpeg' || file.contentType === 'img/png') {
            //read output ot browser
            const readstream = gfs.createReadStream(file.filename);
            readstream.pipe(res);
        }else {
            res.status(404).json({
                err: 'Not an image file'
            });
        }
    });
});

// @route view /files/:id
// @desc  Delete file
app.get('/files/:filename', (req, res) => {
    gfs.files.findOne({_id: req.params.filename}, (err,file) => { 
        if (!file || file.length === 0) {
            return res.status(404).json({
                err: 'No files exist'
            });
        }
        //check if file is jpg or png
        if (file.contentType === 'image/jpeg' || file.contentType === 'img/png') {
            //read output ot browser
            const readstream = gfs.createReadStream(file.filename);
            readstream.pipe(res);
        }else {
            res.status(404).json({
                err: 'Not an image file'
            });
        }
    });
});

app.get(':filename', (req, res) => {
    gfs.files.find(`filename: ${req.params.filename}`).toArray((err, files) => { 
        if (!files || files.length === 0) {
            res.render('index', {files: false});
          } else {
            files.map(file => {
              if (
                file.contentType === 'image/jpeg' || file.contentType === 'image/png') {
                file.isImage = true;
              } else {
                file.isImage = false;
              }
            });
            res.render('index', { files: files });
          }
        //return res.json(files);
    });
});

// @route delete /files/:id
// @desc  Delete file
app.delete('/files/:id', (req, res) => {
    gfs.remove({ _id: req.params.id, root: 'upload' }, (err, gridFsStore) => {
      if (err) {
        return res.status(404).json({ err: err });
      }
  
      res.redirect('/');
    });
});

/*
    The bellow code sets up the view port for the web app using
    local host at the specified port
*/
//tells node which folder to access for the webpage
app.set('views', './view');

//tells node the HTLM styl will be in ejs(Embeded JavaScript)
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    gfs.files.find().toArray((err, files) => {
      // Check if files
      if (!files || files.length === 0) {
        res.render('index', { files: false });
      } else {
        files.map(file => {
          if (
            file.contentType === 'image/jpeg' || file.contentType === 'image/png') {
            file.isImage = true;
          } else {
            file.isImage = false;
          }
        });
        res.render('index', { files: files });
      }
    });
  });

const PORT = 3000;

app.listen(PORT, () => 
console.log(`Server up on PORT ${PORT}`)
);